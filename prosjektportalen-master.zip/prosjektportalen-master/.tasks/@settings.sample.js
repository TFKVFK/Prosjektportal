'use strict';
module.exports = {
    siteUrl: "",
    username: "",
    password: "",    
    language: 1044
}