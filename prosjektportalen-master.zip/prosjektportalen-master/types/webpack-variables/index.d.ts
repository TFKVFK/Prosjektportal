declare var __VERSION: string;
