export interface IBaseFormModifications {
    NewForm?(): void;
    EditForm?(): void;
    DispForm?(): void;
    AllItems?(): void;
}
