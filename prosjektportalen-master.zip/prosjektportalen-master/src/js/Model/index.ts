import {
    ProjectModel,
    IProjectModel,
} from "./ProjectModel";
import PhaseModel from "./PhaseModel";

export {
    ProjectModel,
    IProjectModel,
    PhaseModel,
};
