enum DataSource {
    Search,
    List,
}

export default DataSource;
