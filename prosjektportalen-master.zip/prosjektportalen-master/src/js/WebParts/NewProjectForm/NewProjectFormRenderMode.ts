enum NewProjectFormRenderMode {
    Default,
    Dialog,
}

export default NewProjectFormRenderMode;
