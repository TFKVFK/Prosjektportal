interface ICreationModalState {
    percentComplete: number;
}

export default ICreationModalState;
