export default interface IRiskMatrixState {
    data?: any[];
    selectedRisk?: any;
    showDialog?: boolean;
    postAction?: boolean;
    hideLabels?: boolean;
}
