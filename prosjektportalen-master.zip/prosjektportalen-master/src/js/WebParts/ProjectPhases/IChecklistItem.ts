export default interface IChecklistItem {
    ID: string;
    Title: string;
    GtProjectPhase: any;
    GtChecklistStatus: string;
    GtComment: string;
}
