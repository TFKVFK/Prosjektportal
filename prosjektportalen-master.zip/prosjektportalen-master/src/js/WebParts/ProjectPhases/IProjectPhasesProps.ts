import { IBaseWebPartProps } from "../@BaseWebPart";

export default interface IProjectPhasesProps extends IBaseWebPartProps { }

