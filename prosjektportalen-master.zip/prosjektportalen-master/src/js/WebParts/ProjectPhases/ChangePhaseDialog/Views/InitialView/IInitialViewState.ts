export default interface IInitialViewState {
    comment: string;
}
