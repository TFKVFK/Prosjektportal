import IChecklistItem from "../../../../IChecklistItem";

export default interface IChecklistItemProps {
    checkListItem: IChecklistItem;
}
