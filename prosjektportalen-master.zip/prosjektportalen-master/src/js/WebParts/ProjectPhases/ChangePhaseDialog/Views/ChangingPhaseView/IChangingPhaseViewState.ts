export default interface IChangingPhaseViewState {
    percentComplete: number;
}
