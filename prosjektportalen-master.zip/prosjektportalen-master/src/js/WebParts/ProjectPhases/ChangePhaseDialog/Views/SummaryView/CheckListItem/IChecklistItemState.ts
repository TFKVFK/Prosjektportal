export default interface IChecklistItemState {
    showComment: boolean;
}
