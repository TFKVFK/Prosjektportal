import { IColumn } from "office-ui-fabric-react/lib/DetailsList";

export default interface IBenefitsOverviewData {
    items?: any[];
    columns?: IColumn[];
}
