interface IGroupByOption {
    key: string;
    name: string;
}

export default IGroupByOption;
