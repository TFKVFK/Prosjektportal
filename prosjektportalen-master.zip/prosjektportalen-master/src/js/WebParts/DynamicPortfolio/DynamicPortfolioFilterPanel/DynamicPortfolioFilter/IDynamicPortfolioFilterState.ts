import IDynamicPortfolioFilter from "./IDynamicPortfolioFilter";

export default interface IDynamicPortfolioFilterState {
    isCollapsed: boolean;
    filter?: IDynamicPortfolioFilter;
}
