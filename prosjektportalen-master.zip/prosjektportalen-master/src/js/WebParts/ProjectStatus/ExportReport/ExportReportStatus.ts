enum ExportReportStatus {
    default,
    isExporting,
    hasExported,
}

export default ExportReportStatus;
