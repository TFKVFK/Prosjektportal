export default interface IFileTypeButton {
    save: string;
    isSaved: string;
    saving: string;
    icon?: string;
}
