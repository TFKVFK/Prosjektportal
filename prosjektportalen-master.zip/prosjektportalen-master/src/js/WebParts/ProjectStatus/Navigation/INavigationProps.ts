import SectionModel from "../Section/SectionModel";

export default interface INavigationProps {
    sections: SectionModel[];
    project: any;
    exportType: string;
}
