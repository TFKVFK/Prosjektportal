export default interface IProjectStatusSectionConfig {
    listTitle?: string;
    orderBy?: string;
}
