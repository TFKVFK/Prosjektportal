import SectionModel from "../SectionModel";

export default interface ITopSectionProps {
    project: any;
    sections: SectionModel[];
}
