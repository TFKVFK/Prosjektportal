import SectionModel from "../../SectionModel";

export default interface IStatusElementProps {
    section: SectionModel;
    scrollTo: string;
}
