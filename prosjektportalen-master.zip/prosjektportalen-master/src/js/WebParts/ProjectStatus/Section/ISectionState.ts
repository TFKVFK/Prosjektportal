import ISectionListData from "./ISectionListData";

export default interface ISectionState {
    isLoading?: boolean;
    listData?: ISectionListData;
}
