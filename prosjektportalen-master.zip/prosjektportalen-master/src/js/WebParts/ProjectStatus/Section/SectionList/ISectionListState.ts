import ISectionListData from "../ISectionListData";

export default interface ISectionListState {
    listData?: ISectionListData;
}
