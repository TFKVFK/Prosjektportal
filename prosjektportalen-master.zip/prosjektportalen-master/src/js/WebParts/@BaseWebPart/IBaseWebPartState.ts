export default interface IBaseWebPartState {
    isLoading?: boolean;
    error?: any;
}

