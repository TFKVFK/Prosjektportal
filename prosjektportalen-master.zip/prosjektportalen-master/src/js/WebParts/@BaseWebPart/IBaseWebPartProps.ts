export default interface IBaseWebPartProps extends React.HTMLAttributes<HTMLElement> {}
