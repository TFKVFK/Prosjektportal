export interface IChromeTitleState {
    isCollapsed: boolean;
}

export default IChromeTitleState;
