export default interface IToggleElementStorage {
    key: string;
    type: "localStorage" | "sessionStorage";
}
