export default interface IModalLinkState {
    shouldRender?: boolean;
}
