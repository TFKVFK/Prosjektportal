import ModalLinkIconPosition from "./ModalLinkIconPosition";

export default interface IModalLinkIconProps {
    iconName: any;
    position?: ModalLinkIconPosition;
}


