enum ModalLinkIconPosition {
    Left,
    Right,
}

export default ModalLinkIconPosition;

