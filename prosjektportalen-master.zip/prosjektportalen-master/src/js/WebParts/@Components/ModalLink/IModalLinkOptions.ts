export default interface IModalLinkOptions {
    HideWebPartMaintenancePageLink?: boolean;
    HideContentTypeChoice?: boolean;
    HideFormFields?: string;
    HideViewSelector?: boolean;
    HideRibbon?: boolean;
}

