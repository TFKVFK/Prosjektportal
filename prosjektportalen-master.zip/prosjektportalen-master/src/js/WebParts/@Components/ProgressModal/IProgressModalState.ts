interface IProgressModalState {
    percentComplete: number;
}

export default IProgressModalState;
