import { IBaseWebPartProps } from "../@BaseWebPart";

export default interface IWebPropertyBagEditorProps extends IBaseWebPartProps {}
export const WebPropertyBagEditorDefaultProps: Partial<IWebPropertyBagEditorProps> = {};
