enum ProjectInfoRenderMode {
    Normal,
    Modal,
}

export default ProjectInfoRenderMode;

