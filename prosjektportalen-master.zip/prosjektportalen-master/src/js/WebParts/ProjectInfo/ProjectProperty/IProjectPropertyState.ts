interface IProjectPropertyState {
    truncate: boolean;
}

export default IProjectPropertyState;
