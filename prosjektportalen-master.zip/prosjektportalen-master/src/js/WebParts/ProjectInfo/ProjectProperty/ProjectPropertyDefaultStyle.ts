const ProjectPropertyDefaultStyle: React.CSSProperties = {
    margin: "0 0 10px 0",
    maxWidth: "95%",
};

export default ProjectPropertyDefaultStyle;
