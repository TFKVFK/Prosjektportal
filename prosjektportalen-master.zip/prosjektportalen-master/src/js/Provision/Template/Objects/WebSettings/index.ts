import { IWebSettings } from "sp-pnp-provisioning/lib/schema";

const WebSettings: IWebSettings = {
    WelcomePage: "SitePages/ProjectHome.aspx",
};

export default WebSettings;
