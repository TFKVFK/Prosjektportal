interface IProgressCallback {
    (step: string, progress: string): void;
}

export default IProgressCallback;
