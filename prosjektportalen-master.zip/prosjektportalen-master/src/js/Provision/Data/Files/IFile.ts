export default interface IFile {
    Title: string;
    LinkFilename: string;
    FileRef: string;
    FileDirRef: string;
    Blob: any;
}
